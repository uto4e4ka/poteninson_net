
from enum import Enum
from pydantic import BaseModel


class PlaceholderType(str, Enum):
    TEXT = "text"
    MENTION = "mention"
    CHANNEL = "channel"
    ROLE = "role"


class Placeholder(BaseModel):
    type: PlaceholderType
    value: str | int


class NatsMessage(BaseModel):
    text: str
    placeholders: dict[str, Placeholder] = {}